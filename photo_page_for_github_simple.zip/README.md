Page statique contenant une image et un index.html.
Pour GitHub Pages : mettre ces fichiers à la racine du repo et activer Pages sur la branche main (root).
